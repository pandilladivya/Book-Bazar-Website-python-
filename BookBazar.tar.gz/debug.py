#!usr/bin/env python
print("Content-Type:text/html")
print
import cgitb;cgitb.enable()
print(1/0)
